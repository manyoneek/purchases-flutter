import 'dart:async';
import 'dart:convert';
import 'dart:js_interop';
import 'package:flutter/material.dart';
import 'package:purchases_flutter/purchases_flutter.dart';
import 'config.dart';
@JS('window.rcEventsJSON')
external JSString get browserEvents;
@JS('navigator.onLine')
external JSBoolean get browserOnline;
void main() => runApp(const Reporter());
class Reporter extends StatefulWidget {
  const Reporter({super.key});
  @override
  State<Reporter> createState() => _ReporterState();
}
class _ReporterState extends State<Reporter> {
  final events = <String>[];
  String uncaught = 'None observed';
  bool configured = false;
  bool online = true;
  final user = 'bug-reporter-web-${DateTime.now().millisecondsSinceEpoch}';
  Timer? timer;
  @override
  void initState() {
    super.initState();
    timer = Timer.periodic(const Duration(milliseconds: 250), (_) {
      if (online != browserOnline.toDart) setState(() => online = browserOnline.toDart);
      final value = browserEvents.toDart;
      if (value != '[]' && value != uncaught) setState(() => uncaught = value);
    });
  }
  @override
  void dispose() { timer?.cancel(); super.dispose(); }
  void log(String s) => setState(() => events.add('${DateTime.now().toIso8601String().substring(11,23)}  $s'));
  Future<void> proxy() async {
    log('Calling await Purchases.setProxyURL("https://proxy.invalid")');
    try { await Purchases.setProxyURL('https://proxy.invalid'); log('Proxy setter completed successfully.'); }
    catch (e) { log('Proxy setter FAILED: $e'); }
  }
  Future<void> configure() async {
    log('Configuring dedicated Test Store user: $user');
    try {
      await Purchases.configure(PurchasesConfiguration(sdkKey)..appUserID = user);
      final info = await Purchases.getCustomerInfo();
      final offerings = await Purchases.getOfferings();
      log('Real backend initialized. User: ${info.originalAppUserId}; packages: ${offerings.current?.availablePackages.length}');
      setState(() => configured = true);
    } catch (e) { log('Configuration failed: $e'); }
  }
  Future<void> attributes() async {
    final operations = <String, Future<void> Function()>{
      'setAttributes': () => Purchases.setAttributes({'qa_case': 'promise-boundary'}),
      'setEmail': () => Purchases.setEmail('sdk-qa@example.invalid'),
      'setPhoneNumber': () => Purchases.setPhoneNumber('+15555550123'),
      'setDisplayName': () => Purchases.setDisplayName('Synthetic QA User'),
    };
    for (final entry in operations.entries) {
      final clock = Stopwatch()..start();
      log('${entry.key}: awaiting public Future...');
      try { await entry.value(); log('${entry.key}: Future SUCCESS after ${clock.elapsedMilliseconds} ms'); }
      catch (e) { log('${entry.key}: Future ERROR after ${clock.elapsedMilliseconds} ms: $e'); }
    }
  }
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'RevenueCat Bug Reporter',
    theme: ThemeData(colorSchemeSeed: const Color(0xff4753c7), brightness: Brightness.dark, useMaterial3: true),
    home: Scaffold(body: SafeArea(child: SingleChildScrollView(padding: const EdgeInsets.all(28), child: Center(child: SizedBox(width: 1080, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('RevenueCat · SDK Bug Reporter', style: TextStyle(fontSize: 28,fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Flutter web · commit 2218dec4 · actual public SDK calls · ${String.fromEnvironment('VARIANT', defaultValue: 'original')}', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 12),
      Text('Browser network: ${online ? "Online" : "Offline"}', style: TextStyle(color: online ? Colors.greenAccent : Colors.orangeAccent)),
      const SizedBox(height: 12),
      const Text('01 / Proxy configuration',style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const Text('Run before configuration. Expected: storing the URL completes successfully.'),
      const SizedBox(height: 8),
      FilledButton(onPressed: configured ? null : proxy, child: const Text('Run proxy case')),
      const SizedBox(height: 22),
      const Text('02 / Attribute completion and errors',style: TextStyle(fontSize:20,fontWeight:FontWeight.bold)),
      const Text('Initialize online, then use Chrome DevTools → Network → Offline. Run the setters and wait for the SDK operation. Expected: each Future reflects its real operation.'),
      const SizedBox(height: 8),
      Wrap(spacing:12,children:[FilledButton(onPressed: configured ? null : configure,child:const Text('Initialize Test Store')), FilledButton(onPressed: configured ? attributes : null,child:const Text('Run attribute setters'))]),
      const SizedBox(height: 20),
      const Text('Public API results',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      Container(width:double.infinity,padding:const EdgeInsets.all(14),margin:const EdgeInsets.symmetric(vertical:8),decoration:BoxDecoration(color:const Color(0xff1b2132),borderRadius:BorderRadius.circular(8)),child:Text(events.isEmpty ? 'Ready. Choose a case.' : events.join('\n'),style:const TextStyle(fontFamily:'monospace',fontSize:14))),
      const Text('Browser unhandled promise rejections',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      Text(uncaught == 'None observed' ? uncaught : (jsonDecode(uncaught) as List).asMap().entries.map((e) { final reason = jsonDecode(e.value['reason']); return '#${e.key + 1}  Unhandled code ${reason["code"]}: ${reason["message"]}'; }).join('\n\n'),style:const TextStyle(fontFamily:'monospace',fontSize:13,color:Colors.orangeAccent)),
      const SizedBox(height: 16),
      const Text('No mocked SDK functions or callback injection. Dedicated synthetic Test Store user; no real charges.',style:TextStyle(color:Colors.white54)),
    ])))))));
}
