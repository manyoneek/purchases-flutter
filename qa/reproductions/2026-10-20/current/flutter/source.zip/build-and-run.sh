#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
variant="${1:-before}"
export LANG=en_US.UTF-8 LC_ALL=en_US.UTF-8
mkdir -p app/vendor/purchases_flutter
tar -xzf sdk-source.tar.gz -C app/vendor/purchases_flutter
if [ "$variant" = fixed ]; then (cd app/vendor/purchases_flutter && patch -p1 < ../../../fixes/attributes.patch); fi
(cd app && flutter pub get && flutter build web --dart-define="VARIANT=$variant")
python3 -m http.server 8877 --bind 127.0.0.1 --directory app/build/web
