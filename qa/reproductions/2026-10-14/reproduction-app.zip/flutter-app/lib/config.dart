// Public Test Store key. No secret API credentials.
const sdkKey = "test_REPLACE_WITH_YOUR_PUBLIC_TEST_STORE_KEY";
